import { useEffect, useRef, useState } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

import cloud4 from "@/assets/cloud/cloud4.png";
import cloud2 from "@/assets/cloud/cloud2.png";
import cloud3 from "@/assets/cloud/cloud3.png";
import skyToHouse from "@/assets/hero-update.png";
import cloud1 from "@/assets/cloud/cloud1.png";
import cloud5 from "@/assets/cloud/cloud5.png";
import cloud6 from "@/assets/cloud/cloud6.png";

type CloudItem = {
  id: number;
  src: string;
  name: string;
  layer: "drift-front" | "drift-mid" | "drift-back";
  left: string;
  top: string;
  width: string;
  opacity: number;
  zIndex: number;
  imageTransform?: string;
};

const CLOUDS: CloudItem[] = [
  {
    id: 1,
    src: cloud5,
    name: "left-main-bright",
    layer: "drift-front",
    left: "13.8%",
    top: "29.5%",
    width: "32vw",
    opacity: 0.96,
    zIndex: 12,
    imageTransform: "rotate(-8deg)",
  },
  {
    id: 2,
    src: cloud6,
    name: "upper-mid-thin-back",
    layer: "drift-back",
    left: "46.8%",
    top: "14.2%",
    width: "14vw",
    opacity: 0.28,
    zIndex: 5,
    imageTransform: "rotate(10deg) scaleY(0.92)",
  },
  {
    id: 3,
    src: cloud4,
    name: "center-soft-back",
    layer: "drift-back",
    left: "43.5%",
    top: "39.5%",
    width: "23vw",
    opacity: 0.36,
    zIndex: 6,
    imageTransform: "rotate(8deg)",
  },
  {
    id: 4,
    src: cloud1,
    name: "top-right-bright-main",
    layer: "drift-front",
    left: "82.5%",
    top: "16.8%",
    width: "26vw",
    opacity: 0.98,
    zIndex: 13,
    imageTransform: "rotate(-10deg)",
  },
  {
    id: 5,
    src: cloud2,
    name: "right-mid-thin",
    layer: "drift-mid",
    left: "64.5%",
    top: "36.5%",
    width: "20vw",
    opacity: 0.62,
    zIndex: 8,
    imageTransform: "rotate(-15deg) scaleY(0.88)",
  },
  {
    id: 6,
    src: cloud3,
    name: "upper-left-small-back",
    layer: "drift-back",
    left: "27.8%",
    top: "24.0%",
    width: "13vw",
    opacity: 0.24,
    zIndex: 4,
    imageTransform: "rotate(5deg)",
  },
];

export const SkyScene = ({ ready = true }: { ready?: boolean }) => {
  const root = useRef<HTMLDivElement>(null);
  const [assetsReady, setAssetsReady] = useState(false);

  // ── Tunggu gambar utama benar-benar loaded sebelum ScrollTrigger dibuat ──
  useEffect(() => {
    const img = new Image();
    img.src = skyToHouse;
    if (img.complete) {
      setAssetsReady(true);
    } else {
      img.onload = () => setAssetsReady(true);
      img.onerror = () => setAssetsReady(true);
    }
  }, []);

  // ── Entrance: "Livora" letters + subtitle ──
  useEffect(() => {
    if (!ready) return;

    const ctx = gsap.context(() => {
      gsap
        .timeline()
        .fromTo(
          ".hero-letter",
          { yPercent: 115, opacity: 0 },
          {
            yPercent: 0,
            opacity: 1,
            duration: 1.2,
            stagger: 0.07,
            ease: "power4.out",
          }
        )
        .fromTo(
          ".hero-sub, .hero-scroll",
          { opacity: 0, y: 20 },
          {
            opacity: 1,
            y: 0,
            duration: 0.9,
            stagger: 0.1,
            ease: "power3.out",
          },
          "-=0.5"
        );

      gsap.to(".drift-front", {
        xPercent: 0.8,
        yPercent: -0.35,
        duration: 12,
        ease: "sine.inOut",
        repeat: -1,
        yoyo: true,
      });

      gsap.to(".drift-mid", {
        xPercent: -0.55,
        yPercent: 0.25,
        duration: 15,
        ease: "sine.inOut",
        repeat: -1,
        yoyo: true,
      });

      gsap.to(".drift-back", {
        xPercent: 0.35,
        yPercent: -0.18,
        duration: 18,
        ease: "sine.inOut",
        repeat: -1,
        yoyo: true,
      });
    }, root);

    return () => ctx.revert();
  }, [ready]);

  // ── Scroll-scrubbed cinematic timeline ──
  useEffect(() => {
    if (!assetsReady) return;

    gsap.registerPlugin(ScrollTrigger);

    // Abaikan resize palsu dari address bar mobile saat scroll
    ScrollTrigger.config({ ignoreMobileResize: true });

    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    if (reduced) {
      // Jangan skip total — tetap tampilkan konten akhir tanpa animasi,
      // supaya user dengan macOS Reduce Motion tetap bisa lihat
      // "Imagine. Create. Realize." dan bukan layar kosong/statis di awal.
      gsap.set(".cloud-1, .cloud-2, .cloud-3, .cloud-4, .cloud-5, .cloud-6", { opacity: 0 });
      gsap.set(".hero-title, .hero-scroll", { opacity: 0 });
      gsap.set(".scene-img", { yPercent: -50 });
      gsap.set(".house-overlay", { opacity: 1 });
      gsap.set(".interior-line", { opacity: 1, yPercent: 0 });
      gsap.set(".interior-body", { opacity: 1, y: 0 });
      return;
    }

    const ctx = gsap.context(() => {
      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: root.current,
          start: "top top",
          end: "bottom bottom",
          scrub: 1.05,
        },
      });

      tl.to(".cloud-1", { xPercent: -92, yPercent: -28, opacity: 0, ease: "power2.in" }, 0)
        .to(".cloud-2", { xPercent: 10, yPercent: -50, opacity: 0, ease: "power2.in" }, 0.02)
        .to(".cloud-3", { xPercent: -8, yPercent: 18, opacity: 0, ease: "power2.in" }, 0.04)
        .to(".cloud-4", { xPercent: 72, yPercent: -30, opacity: 0, ease: "power2.in" }, 0)
        .to(".cloud-5", { xPercent: 44, yPercent: -14, opacity: 0, ease: "power2.in" }, 0.03)
        .to(".cloud-6", { xPercent: -28, yPercent: -10, opacity: 0, ease: "power2.in" }, 0.02)
        .to(
          ".hero-title",
          {
            yPercent: -60,
            scaleX: 1.35,
            scaleY: 1.35,
            opacity: 0,
            filter: "blur(6px)",
            ease: "power2.in",
          },
          0
        )
        .to(".hero-scroll", { opacity: 0, y: -30, ease: "power2.in" }, 0)
        .fromTo(
          ".scene-img",
          { yPercent: 0 },
          { yPercent: -50, ease: "none", duration: 1.6 },
          0
        )
        .fromTo(
          ".house-overlay",
          { opacity: 0 },
          { opacity: 1, duration: 0.5, ease: "power2.out" },
          1.3
        )
        .fromTo(
          ".interior-line",
          { yPercent: 110, opacity: 0 },
          {
            yPercent: 0,
            opacity: 1,
            stagger: 0.12,
            ease: "power3.out",
            duration: 0.7,
          },
          1.4
        )
        .fromTo(
          ".interior-body",
          { opacity: 0, y: 24 },
          { opacity: 1, y: 0, duration: 0.6 },
          1.9
        );
    }, root);

    requestAnimationFrame(() => ScrollTrigger.refresh());

    return () => ctx.revert();
  }, [assetsReady]);

  // ── Typewriter tidak ada di file ini (itu ada di Hero.tsx yang lain) ──

  return (
    <section id="top" ref={root} className="relative h-[380vh]">
      <div className="sticky top-0 h-screen overflow-hidden bg-[#8CC0E8]">
        <div className="absolute inset-0 overflow-hidden">
          <div className="scene-img absolute left-0 top-0 h-[200%] w-full will-change-transform">
            <img
              src={skyToHouse}
              alt=""
              aria-hidden
              draggable={false}
              width={1920}
              height={2160}
              className="h-full w-full select-none object-cover"
            />
          </div>
        </div>

        <div className="pointer-events-none absolute inset-0 z-[8] overflow-hidden">
          {CLOUDS.map((cloud) => (
            <div
              key={cloud.id}
              className={`cloud-${cloud.id} absolute`}
              style={{
                left: cloud.left,
                top: cloud.top,
                width: cloud.width,
                zIndex: cloud.zIndex,
              }}
            >
              <div className="-translate-x-1/2 -translate-y-1/2">
                <div className={cloud.layer}>
                  <img
                    src={cloud.src}
                    alt=""
                    aria-hidden
                    draggable={false}
                    className="block h-auto w-full max-w-none select-none"
                    style={{
                      opacity: cloud.opacity,
                      transform: cloud.imageTransform,
                      transformOrigin: "center center",
                    }}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="hero-title absolute inset-0 z-20 flex flex-col items-center justify-center px-6">
          <h1 className="serif flex overflow-hidden text-[22vw] font-light leading-[0.85] text-background sm:text-[14vw]">
            {"Livora".split("").map((c, i) => (
              <span key={i} className="hero-letter block" style={{ textShadow: "0 2px 16px rgba(0,0,0,0.08)" }}>
                {c}
              </span>
            ))}
          </h1>

          <p className="hero-sub mt-6 text-[11px] uppercase tracking-[0.45em] text-background/85">
            Interior Design &amp; Furniture
          </p>
        </div>

        <div className="hero-scroll absolute bottom-10 left-1/2 z-20 -translate-x-1/2 text-[10px] uppercase tracking-[0.4em] text-background/75">
          Scroll
        </div>

        <div className="house-overlay absolute inset-0 z-30 opacity-0">
          <div className="absolute inset-0 bg-gradient-to-r from-foreground/90 via-foreground/45 to-transparent" />
          <div className="absolute inset-0 flex items-center">
            <div className="container-livora">
              <span className="interior-line block text-[20px] uppercase tracking-[0.4em] text-background/70">
                PT. Langgeng Cipta Ruang
              </span>

              <div className="mt-6 ">
                {["Imagine.", "Create.", "Realize."].map((w) => (
                  <span key={w} className="block overflow-hidden">
                    <span className="interior-line serif block text-[13vw] font-light leading-[1] text-background sm:text-[5.2vw]">
                      {w}
                    </span>
                  </span>
                ))}
              </div>

              <p className="interior-body mt-8 max-w-md text-sm font-light leading-relaxed text-background/80 opacity-0 transition-opacity duration-20 ease-in-out sm:text-base">
                Create your dream space with us — a single point of contact for design, supply and
                construction.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SkyScene;