import { Link } from "react-router-dom";
import { ArrowUpRight, Megaphone, Sparkles } from "lucide-react";
import { PageHeader } from "@/components/admin/PageHeader";
import { PlatformRow, TableShell } from "@/components/ai/offline";
import { ActivityStream } from "@/components/ai/activity-stream";
import { AgentRail } from "@/components/ai/agent-rail";
import { KpiCard } from "@/components/ai/kpi-card";
import { PriorityList } from "@/components/ai/priority-list";
import { RecommendationCard } from "@/components/ai/recommendation-card";
import { Panel, Pill, Reveal, SectionHeading, Sparkline, StatusDot } from "@/components/ai/primitives";
import { SectionNotice } from "@/components/ai/section-state";
import { typeMeta } from "@/components/ai/insight-card";
import { usePageContext } from "@/context/AiMarketingContext";
import { useSectionState } from "@/hooks/useSectionState";
import { AdRoasKpiCard, AvgEngagementKpiCard, PerformanceOverviewPanel, SocialPerformanceRows } from "@/components/ai/marketing-panels";
import {
  useAiActivity,
  useAiAgents,
  useAiInsights,
  useCampaigns,
  useOverviewKpis,
  usePriorities,
  useRecommendations,
} from "@/hooks/useAiDashboard";

import type { AIInsight, AIKpi, Campaign, CampaignHealth } from "@/lib/ai/types";

const healthTone: Record<CampaignHealth, "success" | "warning" | "danger"> = {
  Good: "success",
  Fair: "warning",
  "Needs Attention": "danger",
};

/** Channel string dari backend bebas teks — cocokkan ke 2 platform ads yang
 *  panel ini peduli. Campaign lain (organic/email/dll) tidak masuk sini,
 *  itu ranahnya bukan "Campaign Performance (Ads)". */
function matchesAdPlatform(channel: string, platform: "meta" | "google"): boolean {
  const c = channel.toLowerCase();
  if (platform === "meta") return c.includes("meta") || c.includes("facebook") || c.includes("instagram");
  return c.includes("google");
}

const kpiTones = ["success", "info", "warning", "ai"] as const;

function Block({
  loading,
  error,
  empty,
  emptyText,
  height = "h-28",
  children,
}: {
  loading: boolean;
  error: unknown;
  empty?: boolean;
  emptyText?: string;
  height?: string;
  children: React.ReactNode;
}) {
  if (loading) {
    return <div className={`w-full animate-pulse rounded-sm border border-border bg-surface/40 ${height}`} />;
  }
  if (error) {
    return (
      <p className="rounded-sm border border-dashed border-border-strong p-6 text-center text-sm text-muted-foreground">
        Data tidak bisa dimuat dari server. Coba muat ulang halaman.
      </p>
    );
  }
  if (empty) {
    return (
      <p className="rounded-sm border border-dashed border-border-strong p-8 text-center text-sm text-muted-foreground">
        {emptyText ?? "Belum ada data."}
      </p>
    );
  }
  return <>{children}</>;
}

function InsightRow({ insight }: { insight: AIInsight }) {
  const meta = typeMeta[insight.type];
  return (
    <Link
      to="/admin/ai-marketing/insights"
      className="group flex items-start gap-3 rounded-sm border border-border p-3.5 transition-colors hover:bg-accent/40"
    >
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-medium leading-snug group-hover:text-foreground">
          {insight.title}
        </p>
        <p className="mt-0.5 line-clamp-1 text-xs text-muted-foreground">{insight.description}</p>
      </div>
      <Pill tone={meta.tone} className="shrink-0">
        <StatusDot tone={meta.tone} pulse={insight.severity === "critical"} />
        {insight.severity}
      </Pill>
    </Link>
  );
}

/** Satu baris platform ads di panel "Campaign Performance" — dipakai kalau
 *  ada minimal satu AiCampaign yang channel-nya cocok. Menampilkan metric
 *  ASLI dari campaign tsb (metric.value/deltaLabel/spark dari backend),
 *  bukan spend/ROAS hasil hitungan sendiri — backend belum punya angka itu. */
function AdPlatformRow({ platform, campaigns }: { platform: string; campaigns: Campaign[] }) {
  if (campaigns.length === 0) {
    return <PlatformRow icon={Megaphone} label={platform} />;
  }
  // Kalau lebih dari satu campaign match, tampilkan yang health-nya paling butuh perhatian.
  const rank: Record<CampaignHealth, number> = { "Needs Attention": 0, Fair: 1, Good: 2 };
  const lead = [...campaigns].sort((a, b) => rank[a.health] - rank[b.health])[0];
  return (
    <Link
      to="/admin/ai-marketing/campaigns"
      className="flex items-center gap-3 rounded-sm border border-border px-3.5 py-3 transition-colors hover:bg-accent/40"
    >
      <Megaphone className="size-4 shrink-0 text-muted-foreground" />
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <span className="text-sm">{platform}</span>
          <Pill tone={healthTone[lead.health]} className="shrink-0">
            {lead.health}
          </Pill>
        </div>
        <p className="truncate text-[11px] text-muted-foreground">
          {campaigns.length} campaign{campaigns.length > 1 ? "s" : ""} · {lead.metric.label}: {lead.metric.value}
          {lead.budgetDaily ? ` · ${lead.budgetDaily}` : ""}
        </p>
      </div>
      {lead.spark.length > 1 ? (
        <Sparkline
          points={lead.spark}
          tone={lead.metric.deltaDirection === "down" ? "danger" : "success"}
          className="w-16 shrink-0"
        />
      ) : null}
    </Link>
  );
}


export default function AiMarketingOverview() {
  usePageContext("overview");

  const kpis = useOverviewKpis();
  const kpiSection = useSectionState(kpis);
  const priorities = usePriorities();
  const agents = useAiAgents();
  const pendingRecs = useRecommendations("pending");
  const insights = useAiInsights();
  const activity = useAiActivity();
  const campaigns = useCampaigns();

  const topInsights = (insights.data ?? []).slice(0, 4);
  const metaCampaigns = (campaigns.data ?? []).filter((c) => matchesAdPlatform(c.channel, "meta"));
  const googleCampaigns = (campaigns.data ?? []).filter((c) => matchesAdPlatform(c.channel, "google"));

  const topRecommendations = [...(pendingRecs.data ?? [])]
    .sort((a, b) => {
      const order = { high: 0, medium: 1, low: 2 } as const;
      return order[a.priority ?? "medium"] - order[b.priority ?? "medium"];
    })
    .slice(0, 4);

  return (
    <>
      <PageHeader
        eyebrow="AI Marketing"
        title="Overview"
        description="Real-time intelligence and recommendations for Livora's digital growth."
      />

      {/* KPI row — live KPI + slot terkunci untuk metrik yang butuh integrasi.
          Semua sembilan status lewat SectionState sekarang, lewat KpiCard —
          tidak ada lagi komponen LockedKpiCard terpisah (Phase 1, fondasi). */}
      <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 xl:grid-cols-6">
        {kpiSection.status === "loading" ? (
          [0, 1, 2, 3, 4, 5].map((i) => <KpiCard key={i} label="KPI" index={i} state={kpiSection} />)
        ) : kpiSection.status === "data" ? (
          <>
            {kpiSection.data.slice(0, 4).map((k: AIKpi, i: number) => (
              <KpiCard
                key={k.id}
                label={k.label}
                index={i}
                tone={kpiTones[i]}
                state={{ ...kpiSection, data: k }}
              />
            ))}
            <AvgEngagementKpiCard index={4} />
            <AdRoasKpiCard index={5} />
          </>
        ) : (
          <Panel className="col-span-full">
            <SectionNotice state={kpiSection} title="KPI tidak bisa dimuat" height="h-32" />
          </Panel>
        )}
      </div>

      {/* Performance chart + AI Insights */}
      <div className="mt-6 grid gap-4 xl:grid-cols-[1.6fr_1fr]">
        <PerformanceOverviewPanel />

        <Panel className="flex h-full flex-col p-5 sm:p-6">
          <div className="mb-4 flex items-center justify-between gap-3">
            <h3 className="text-display rule-accent text-lg">AI Insights</h3>
            <Link
              to="/admin/ai-marketing/insights"
              className="inline-flex items-center gap-1 text-xs text-muted-foreground transition-colors hover:text-foreground"
            >
              View all <ArrowUpRight className="size-3" />
            </Link>
          </div>
          <Block
            loading={insights.isLoading}
            error={insights.error}
            empty={topInsights.length === 0}
            emptyText="Belum ada insight. Jalankan agent AI di server untuk menghasilkannya."
          >
            <div className="space-y-2.5">
              {topInsights.map((ins) => (
                <InsightRow key={ins.id} insight={ins} />
              ))}
            </div>
          </Block>
        </Panel>
      </div>

      {/* Social + Content Queue + Campaign spend */}
      <div className="mt-6 grid gap-4 lg:grid-cols-2 xl:grid-cols-3">
        <Panel className="flex h-full flex-col p-5 sm:p-6">
          <div className="mb-4 flex items-center justify-between gap-3">
            <h3 className="text-display rule-accent text-lg">Social Performance</h3>
            <span className="text-[11px] text-muted-foreground">(30 Days)</span>
          </div>
          <div className="flex-1"><SocialPerformanceRows /></div>
          <p className="mt-4 text-xs leading-relaxed text-muted-foreground">
            Engagement per platform aktif setelah kredensial Meta / TikTok / YouTube dipasang.
          </p>
        </Panel>

        <TableShell
          title="Content Queue"
          action={
            <Link
              to="/admin/ai-marketing/content"
              className="inline-flex items-center gap-1 text-xs text-muted-foreground transition-colors hover:text-foreground"
            >
              View all <ArrowUpRight className="size-3" />
            </Link>
          }
          columns={["Draft", "Channel", "Scheduled", "Status", "Action"]}
          emptyTitle="Not connected"
          emptyDescription="Antrian konten terjadwal butuh koneksi platform sosial (Meta / TikTok / YouTube) dan endpoint Content Agent belum tersedia di backend."
          rows={3}
        />

        <Panel className="flex h-full flex-col p-5 sm:p-6">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
            <h3 className="text-display rule-accent text-lg">Campaign Performance (30 Days)</h3>
            <Link
              to="/admin/ai-marketing/ads"
              className="inline-flex items-center gap-1 text-xs text-muted-foreground transition-colors hover:text-foreground"
            >
              View report <ArrowUpRight className="size-3" />
            </Link>
          </div>
          <Block
            loading={campaigns.isLoading}
            error={campaigns.error}
            height="h-full min-h-40"
          >
            <div className="flex-1 space-y-2.5">
              <AdPlatformRow platform="Meta Ads" campaigns={metaCampaigns} />
              <AdPlatformRow platform="Google Ads" campaigns={googleCampaigns} />
            </div>
            <p className="mt-4 text-xs leading-relaxed text-muted-foreground">
              {metaCampaigns.length + googleCampaigns.length > 0
                ? "Metric per platform diambil dari AI campaign yang sudah dibuat agent. Spend/ROAS asli tampil setelah akun iklan tersambung."
                : "Belum ada AI campaign untuk Meta Ads atau Google Ads. Baris akan terisi begitu agent membuat rencana untuk platform tsb."}
            </p>
          </Block>
        </Panel>
      </div>

      {/* Today's Top Priorities — LIVE */}
      <section className="mt-10">
        <SectionHeading
          title="Today's Priorities"
          description="The 3–5 things that matter most right now — the AI has already ranked them for you."
        />
        <Block
          loading={priorities.isLoading}
          error={priorities.error}
          empty={(priorities.data ?? []).length === 0}
          emptyText="Belum ada prioritas. Agent AI belum menghasilkan rekomendasi pending."
        >
          <PriorityList items={priorities.data ?? []} />
        </Block>
      </section>

      {/* AI Recommendations — LIVE */}
      <section className="mt-10">
        <SectionHeading
          title="AI Recommendations"
          description="Actionable proposals, not just findings. Approve, reject, or dig into each one."
          action={
            <Link
              to="/admin/ai-marketing/ai-center/recommendations"
              className="inline-flex items-center gap-1.5 text-xs text-muted-foreground transition-colors hover:text-foreground"
            >
              View all <ArrowUpRight className="size-3.5" />
            </Link>
          }
        />
        <Block
          loading={pendingRecs.isLoading}
          error={pendingRecs.error}
          empty={topRecommendations.length === 0}
          emptyText="Tidak ada rekomendasi menunggu persetujuan."
        >
          <div className="grid gap-4 lg:grid-cols-2">
            {topRecommendations.map((r, i) => (
              <Reveal key={r.id} delay={i * 80}>
                <RecommendationCard rec={r} variant="compact" />
              </Reveal>
            ))}
          </div>
        </Block>
      </section>

      {/* AI Activity — LIVE */}
      <section className="mt-10">
        <SectionHeading
          title="AI Activity"
          description="A live trail of what every agent has been doing."
          action={
            <Link
              to="/admin/ai-marketing/activity"
              className="inline-flex items-center gap-1.5 text-xs text-muted-foreground transition-colors hover:text-foreground"
            >
              Full activity log <ArrowUpRight className="size-3.5" />
            </Link>
          }
        />
        <Block
          loading={activity.isLoading}
          error={activity.error}
          empty={(activity.data ?? []).length === 0}
          emptyText="Belum ada aktivitas AI yang tercatat."
        >
          <ActivityStream items={(activity.data ?? []).slice(0, 8)} compact />
        </Block>
      </section>

      {/* Marketing systems — LIVE */}
      <section className="mt-10">
        <SectionHeading
          title="Your Marketing Systems"
          description="Every specialised agent, at a glance. Detail lives on each agent's own page."
        />
        <Block
          loading={agents.isLoading}
          error={agents.error}
          empty={(agents.data ?? []).length === 0}
          emptyText="Belum ada agent terdaftar."
        >
          <AgentRail agents={agents.data ?? []} />
        </Block>
      </section>

      <Panel className="mt-10 p-6">
        <p className="label-eyebrow flex items-center gap-2">
          <Sparkles className="size-3.5 text-ai" />
          How Livora's AI Marketing Operating System fits together
        </p>
        <div className="scroll-rail mt-4 flex gap-3 pb-2">
          {[
            ["Data", "What happened?"],
            ["AI Analysis", "Why did it happen?"],
            ["Priority", "What matters most?"],
            ["Recommendation", "What should we do?"],
            ["Approval", "Should we do it?"],
            ["Action", "Execute it."],
            ["Impact", "Did it work?"],
            ["Learning", "Do more of what works."],
          ].map(([k, v]) => (
            <div key={k} className="w-[176px] shrink-0 rounded-sm border border-border p-4">
              <p className="label-eyebrow text-ai">{k}</p>
              <p className="mt-2 text-sm">{v}</p>
            </div>
          ))}
        </div>
      </Panel>
    </>
  );
}
